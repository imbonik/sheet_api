
CREATE VIEW [dbo].[plot_table] as 
select * from users u, cities c where  u.city_id = c.id
go

